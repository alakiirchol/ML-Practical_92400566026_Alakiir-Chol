#Encoding Data - Label Encoding

import pandas as pd
from sklearn.preprocessing import LabelEncoder

#Load dataset

ds = pd.read_csv("airlines.csv")
#create LabelEncoder Object
label_enc = LabelEncoder()
#Encode 'origin' column
ds["Callsign_encoded"] = label_enc.fit_transform(ds["Callsign"])
print("Encoded Data (Callsign column):\n")
print(ds[["Callsign", "Callsign_encoded"]].head(10))
