#read data set
import pandas as pd

ds = pd.read_csv("airlines.csv")

print("Dataset Records")
print(ds.head(10))
