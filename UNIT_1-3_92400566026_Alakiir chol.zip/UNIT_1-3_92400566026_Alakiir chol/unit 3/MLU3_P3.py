#missing data handling and remove null data

#missing Data

import pandas as pd

df = pd.read_csv("airlines.csv")

print("Missing Values:")
print(df.isnull().sum())


#Removing null Data
ds = df.dropna()
print("After Removing Null Values:")
print(ds.shape)
