#identify category

import pandas as pd

df = pd.read_csv("airlines.csv")

print("Numeric Columns:")
print(df.select_dtypes(include =['int64', 'float64']).columns)

print(\ncategor
