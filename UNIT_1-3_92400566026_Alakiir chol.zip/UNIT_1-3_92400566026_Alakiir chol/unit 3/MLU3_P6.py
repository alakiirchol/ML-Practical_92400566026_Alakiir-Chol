#Feature selection - Correlation

import pandas as pd

df = pd.read_csv("airlines.csv")

correlation = df.corr()

print("Correlation Matrix:")
print(correlation)
