#numpy.fromiter

import numpy as np

iterable = range(5)
arr = np.fromiter(iterable, dtype=int)
print(arr)
