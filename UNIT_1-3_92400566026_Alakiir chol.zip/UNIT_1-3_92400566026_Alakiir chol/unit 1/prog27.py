#percentile()

import numpy as np

arr = np.array([10, 20, 30, 40, 50])

#50th percentile(median)
print(np.percentile(arr, 50))
