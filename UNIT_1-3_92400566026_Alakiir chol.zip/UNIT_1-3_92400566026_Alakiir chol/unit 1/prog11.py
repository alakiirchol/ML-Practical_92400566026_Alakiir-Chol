#numpy.asarray

import numpy as np

list_data = [1,2,3]
arr =np.asarray(list_data)
print(arr)
