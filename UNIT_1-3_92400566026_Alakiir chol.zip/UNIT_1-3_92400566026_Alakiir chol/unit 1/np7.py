import numpy as np
student =np.dtype([('name','s20'),('age','i4'),('marks','f4')])
print(student)
