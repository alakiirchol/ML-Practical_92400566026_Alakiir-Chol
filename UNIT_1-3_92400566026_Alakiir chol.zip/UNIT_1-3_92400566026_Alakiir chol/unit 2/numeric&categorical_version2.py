import pandas as pd

#read dataset
df =pd.read_csv("auto-mpg.csv")
df = pd.read_csv("auto-mpg.csv",na_values ='?')

#numeric columns
num_cols =df..select_dtypes(include ='number').coulmns

#categorical columns
cat_cols =df.select_dtypes(exclude='number').columns

print("Number Attributes:")
print(list(num_cols))

print("\nCategorical Attributes:")
print(list(cat_cols))
