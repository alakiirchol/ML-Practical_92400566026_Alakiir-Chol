import pandas as pd

#force pandas to show everything

pd.set_option('display.max_columns',None)
pd.set_option('display.width',2000)
pd.set_option('display.expand_frame_repr',False)

#Read dataset
ds_csv = pd.read_csv("auto-mpg.csv")

#display output
print("CSV Data (First 10 Rows - ALL columns shown):/n")
print(ds_csv.head(10))
print(ds_csv.head(10).to_string())

print("\nColumn Names:\n")
print(list(ds_csv.columns))
