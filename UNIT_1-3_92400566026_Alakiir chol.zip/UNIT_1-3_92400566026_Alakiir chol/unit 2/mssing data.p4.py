import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

#load dataset
df = pd.read_csv("auto-mpg.csv")

#replace '?' and convert horsepower to numeric
df["horsepower"] = df["horsepower"].replace("?",np.nan)
df["horsepower"] =pd.to_numeric(df["horsepower"])

#filling missing values with mean
df["horsepower"] =df["horsepower"].fillna(df["horsepower"].mean())


num_cols = df.select_dtypes(include =['int64','float64'])

#apply Min-Max Scaling
scaler =MinMaxScaler()
scaleddata = scaler.fit_transform(num_cols)

#convert back to dataframe
scaleddf = pd.DataFrame(scaleddata, columns=num_cols.columns)

print("Rescaled Data:\n")
print(scaleddf.head(10))
