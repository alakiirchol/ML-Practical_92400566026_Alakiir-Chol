import pandas as pd

ds_csv=pd.read_csv("auto-mpg.csv")

print("CSV Data:")

#defaultshow 5 records
print(ds_csv.head())

#shows 10 records
print(ds_csv.head().to_string())
