import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier

#read dataset
ds= pd.read_csv("joboffer.csv")
print("Dataset")
print(ds)

#convert catergorical data into numbers
le=LabelEncoder()

for col in ds.columns:
    ds[col]=le.fit_transform(ds[col])

#separate input features and output
x= ds.drop("Job_offered",axis=1)
y= ds["Job_offered"]

#create Decision Tree Model
model = DecisionTreeClassifier()

#Train the model
model.fit(x,y)

#test data example
#CGPA= High,Communication= Good,Aptitude= High,Programming_skill = Good
#test= [[0,1,0,1]]

test = [[0,1,0,1],[2,1,0,1],[1,0,1,1],[1,1,1,0],[0,1,0,0],[0,1,0,1],[2,0,1,0],[0,0,0,1],
        [2,1,0,1],[1,0,0,0],[1,0,0,0],[2,1,0,0,],[1,1,1,1],[0,0,1,0],[2,0,0,1],[0,0,1,0],[2,1,0,0]]

prediction = model.predict(test)

for dec in range(len(test)):
    if prediction[dec]==1:
        print("Job Offered")
    else:
        print("Job Not offered")
