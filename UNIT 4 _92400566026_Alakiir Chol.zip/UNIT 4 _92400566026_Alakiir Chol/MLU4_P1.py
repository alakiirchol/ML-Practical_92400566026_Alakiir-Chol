import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.naive_bayes import GaussianNB

#read CSV dataset
ds = pd.read_csv("Buycomputer.csv")

print("Dataset:")
print(ds)

#Encode categorical values
le = LabelEncoder()

for col in ds.columns:
    ds[col]= le.fit_transform(ds[col])


#split data into features and target
x = ds.drop("Buyscomputer",axis=1)
y = ds["Buyscomputer"]

#train naive Bayes model
model = GaussianNB ()
model.fit(x,y)

#test = [[2,0,0,1]]
test = [ [2,0,0,1], [2,0,0,0],[0,0,0,1],[1,2,0,1],[1,2,0,1],[1,1,1,1],[0,1,1,0],[1,1,1,0],[2,2,0,1],
         [2,1,1,1],[1,2,1,1],[1,2,1,1],[2,2,1,0],[0,2,0,0],[0,0,1,1]]

columns=["Age","Income","Student","Creditrating"]

prediction = model.predict(test)


for dec in range(len(test)):

  if prediction[dec] ==1:
    print("Person will Buy a computer")
  else:
    print("Person will Not Buy a Computer")

