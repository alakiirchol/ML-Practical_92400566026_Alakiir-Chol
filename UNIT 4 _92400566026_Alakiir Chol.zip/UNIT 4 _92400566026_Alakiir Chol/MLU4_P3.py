import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn. import KNeighborsClassifier

#read dataset
ds= pd.read_csv("Buycomputer.csv")
print("Dataset")
print(ds)

#Encoding categorical values
ds["Age"]= ds["Age"].map({"Youth":2, "Middle":0, "Senior":1})




#separate input features and output
x= ds.drop("Buycomputer",axis=1)
y= ds["Buycomputer"]

#create Decision Tree Model
model = KNeighborsClassifier(n_neighbors=3)
model.fit(x,y)

#Train the model
model.fit(x,y)



test = [[0,1,0,1],[2,1,0,1],[1,0,1,1],[1,1,1,0],[0,1,0,0],[0,1,0,1],[2,0,1,0],[0,0,0,1],
        [2,1,0,1],[1,0,0,0],[1,0,0,0],[2,1,0,0,],[1,1,1,1],[0,0,1,0],[2,0,0,1],[0,0,1,0],[2,1,0,0]]

prediction = model.predict(test)

for dec in range(len(test)):
    if prediction[dec]==1:
        print("Job Offered")
    else:
        print("Job Not offered")
