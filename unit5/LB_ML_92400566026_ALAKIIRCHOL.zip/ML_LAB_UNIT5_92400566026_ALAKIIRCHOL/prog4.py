import pandas as pd
from sklearn.linear_model import LinearRegression

ds = pd.read_csv("houseprice.csv")

X = ds[["SquareFeet","Bedrooms"]]

y = ds["Price"]

model = LinearRegression()

model.fit(X,y)

prediction = model.predict([[3000,3]])

print("Predicted House Price:", prediction[0])