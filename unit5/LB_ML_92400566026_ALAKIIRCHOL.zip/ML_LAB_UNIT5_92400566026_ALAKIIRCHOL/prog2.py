import pandas as pd
from sklearn.linear_model import LinearRegression

# Read dataset
ds = pd.read_csv("hotelchain.csv")

# Separate input and output
X = ds[["Population"]]
y = ds["Profit"]

# Create regression model
model = LinearRegression()

# Train model
model.fit(X, y)

# Predict profit for population = 7.0
prediction = model.predict([[7.0]])

print("Predicted Profit:", prediction[0])