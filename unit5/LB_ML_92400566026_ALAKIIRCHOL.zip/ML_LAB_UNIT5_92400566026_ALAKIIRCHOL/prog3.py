import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

ds = pd.read_csv("SLR.csv")

X = ds[["YearsExperience"]]
y = ds["Salary"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)

model = LinearRegression()

model.fit(X_train, y_train)

prediction = model.predict(X_test)

print("Predicted Salary values:")
print(prediction)