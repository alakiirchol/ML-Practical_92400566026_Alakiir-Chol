import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score

# Load dataset
ds = pd.read_csv("glass.csv")

ds = ds.drop("Id", axis=1)

X = ds.drop("Type", axis=1)
y = ds["Type"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3,random_state=42)

model = GaussianNB()

model.fit(X_train, y_train)

y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)

print("Accuracy:", accuracy)