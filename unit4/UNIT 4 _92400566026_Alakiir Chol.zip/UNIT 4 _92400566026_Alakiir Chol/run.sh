
for p in {1..9}
do 
echo "Running with program $p"
python "MLU4_P${p}.py"
done