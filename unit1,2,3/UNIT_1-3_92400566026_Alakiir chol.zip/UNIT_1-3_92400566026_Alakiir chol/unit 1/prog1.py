import pandas as pd
from io import StringIO
csv_data = '''A, B, C, D
 1, 2, 3, 4
 5, 6, 7, 8
 9, 10, 11,'''

df = pd.DataFrame(StringIO(csv_data))
print("DataFrame:")
print(df)

print("DataFrame columns with Sum")
print(df.isnull().sum())
