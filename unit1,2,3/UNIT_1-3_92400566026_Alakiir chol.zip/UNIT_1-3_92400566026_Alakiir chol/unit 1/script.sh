for i in {1..54}
do 
    echo "Running program $i"
    python "prog${i}".py
done

