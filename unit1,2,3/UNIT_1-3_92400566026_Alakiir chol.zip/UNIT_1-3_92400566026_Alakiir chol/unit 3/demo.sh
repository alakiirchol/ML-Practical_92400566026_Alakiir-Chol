for i in {1..4}
do 
    echo "Running program $i"
    python "MLU3_P${i}".py
done

