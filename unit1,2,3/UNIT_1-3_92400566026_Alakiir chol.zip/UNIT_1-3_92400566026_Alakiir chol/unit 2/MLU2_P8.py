# First Version

import pandas as pd

# read dataset
df = pd.read_csv("auto-mpg.csv")
df = pd.read_csv("auto-mpg.csv", na_values='?')


# find numeric attributes
print("Numeric Attributes:")
print(df.select_dtypes(include='number').columns)

# find categorical attributes
print("\nCategorical Attributes:")
print(df.select_dtypes(include=['object', 'string']).columns)
