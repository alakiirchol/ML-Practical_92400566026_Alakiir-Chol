import pandas as pd

# Read CSV file
df1 = pd.read_csv("auto-mpg.csv")
print("CSV File:")
print(df1.head())

# Read Text file
df2 = pd.read_csv("auto-mpg.txt")
print("\nText File:")
print(df2.head())

# Read JSON File
df3 = pd.read_json("auto-mpg.json")
print("\nJSON File:")
print(df3.head())
