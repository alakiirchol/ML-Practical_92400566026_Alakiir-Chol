for i in {1..9}
do 
    echo "Running program $i"
    python "MLU2_P${i}".py
done

